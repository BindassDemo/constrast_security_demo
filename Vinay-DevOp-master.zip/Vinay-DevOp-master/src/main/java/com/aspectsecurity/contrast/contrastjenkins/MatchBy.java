package com.aspectsecurity.contrast.contrastjenkins;

public enum MatchBy {
    APPLICATION_ORIGIN_NAME, //The name that the application was instrumented with.
    APPLICATION_ID,
    APPLICATION_SHORT_NAME
}
