package com.aspectsecurity.contrast.contrastjenkins;


public class ContrastPluginConfigStub extends ContrastPluginConfig {

    public ContrastPluginConfigStub() {
        super();
    }

    public static class ContrastPluginConfigDescriptorStub extends ContrastPluginConfig.ContrastPluginConfigDescriptor {

        @Override
        public synchronized void load() {
        }
    }
}